# Blur Extension
This Chrome extension is a button that, when clicked, blurs the current page and prevents mouse clicks.
